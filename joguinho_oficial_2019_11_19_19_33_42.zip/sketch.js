src="path/to/p5.sound.js";
var i;//indice do vetor das imagens
var tela=3; //nome autoexplicativo
var x1 //referente à distancia relativa do lixo para a lata
var a1=300,b1=0; //"lixo"
var img=[]; //imagens
var p=0; //pontuação
var p0=10; //barreira de pontos
var n=1; // nivel
var lixo; //lixo que vai descer
var dista=0; //distancia do lixo pra lixeira
var vida=3;//vidas
var somt; // SOM TESTE
var somal=1;//uantidade de lixo que cai
var somat=5; //meta da quantidade
var star;//random da estrela

function setup() {
  createCanvas(600, 450);
  lixo= Math.floor(Math.random()*20+1);
  somt.setVolume(0.1);
  somt.play();
  somt.loop();
  
}

function preload() {
  for(i=0;i<=34;i++){
  img[i]  = loadImage('img'+i+'.png');}  
  soundFormats('mp3','ogg');
  somt=loadSound('musica_cortada.mp3');
}
/*
ESQUEMA DO VETOR DAS IMAGENS
0 - LIXEIRAS
1-4 - RESIDUOS DO PLASTICO
5-8 - RESIDUOS DO PAPEL
9-12 - RESIDUOS DO METAL
13-15 - RESIDUOS DO VIDRO
16-20 - RESIDUOS DO ORGANICO
21 - 23 - CORAÇÕES
24 - ESTRELA AMARELA (acertar a lixeira orgânico)
25 - ESTREKA AZUL (acertar a lixeira metal)
26 - ESTRELA MARROM (acertar a lixeira papel)
27 - ESTRELA VERDE (acertar a lixeira plástico)
28 - ESTRELA VERMELHA (acertar a lixeira vidro)
29 - fundo de primavera
30 - fundo de verão 
31 - fundo de outono
32 - fundo de inverno
33 - fundo da tela de "como jogar"
34 - todas as latas;

*/
function draw() {
  
  if(tela==1){
 background(img[33],600,450);
  //tela inicial
    textSize(68)
    textFont('Concert One');
    stroke(51);
    strokeWeight(3);
     //fonte da frase abaixo
    fill(255,255,0
         );
    text("Coleta Divertida",64,175);
    noStroke();
    fill(173,255,47)
    rect(320, 360, 250, 50, 20);
       textSize(30)
     textFont('Modak');
    fill(34,139,34); 
    //AS ALTERAÇÕES NA TELA INICIAL AQUI 
    text("Como jogar",90,330);
    fill(173,255,47) //cor do retangulo de "pressione enter"
    rect(45, 360, 250, 50, 20);
     fill(34,139,34); // cor das letras da tela
    text("Pressione Enter",60,395);
    text("Pressione CTRL",340,395);
    text("Jogar",400,330);
       if (keyIsDown(13)){
			tela = 2 }//aqui é onde ele aperta o enter
    if(keyIsDown(17)){
    tela=3}
  }
  //tela do jogo
  if(tela==2){
  background(100,100,100);
    fill(34,139,34)
     textSize(40);
     stroke(51);
    strokeWeight(4);
    text("OLÁ, ECOAMIGO!",150,45);
    textSize(30);
    text("Seja bem vindo ao Coleta Divertida",53,90);
    text("apert 'ctrl' para começar",130,420);  
    //rect(12,270,500,100);
     image(img[34],40,240,500,150)
    if(keyIsDown(17)){
    tela=3}
  }
  
  if(tela==3){
    if(n==1||n==5){background(img[29],600,450);}
  else if(n==2||n==6){background(img[30],600,450);}
  else if(n==3||n==7){background(img[31],600,450);}
  else {background(img[32],600,450);}
    
  image(img[0],12, 350,90,100,151,2,122,200);//lixeira plastico
  image(img[0],132,350,90,100,304,1,124,201);//lixeira papel
  image(img[0],258,350,90,100,456,1,124,201);//lixeira metal
  image(img[0],380,350,90,100,1,1,124,204);//lixeira vidro
  image(img[0],499,350,90,100,608,1,122,200)//lixeira organico
    
  if(b1<307){
  b1=b1+1; //velocidade da queda
  }
  else{
  b1=0;
      lixo=Math.floor(Math.random()*20+1);//escolha do residuo
    somal++;
    star=Math.floor(Math.random()*5+1);
  }
  if(p>p0){
    n++;
    p0=p0+10;
  }
   if(a1>600){a1=0}
    if(a1<0){a1=600}
    
  if(somal!==somat){
  if(lixo==1){
    image(img[1],a1,b1,32,60);
    x1=42;
  }
  else if(lixo==2){
  image(img[2],a1,b1,45,50);
    x1=42;
  }
  else if(lixo==3){
  image(img[3],a1,b1,40,55);
    x1=42;
  } 
  else if(lixo==4){
  image(img[4],a1,b1,45,55);
    x1=42;
  }  
  else if(lixo==5){
  image(img[5],a1,b1,49,47);
    x1=162;
  }
  else if(lixo==6){
  image(img[6],a1,b1,30,45);
    x1=162;
  }
  else if(lixo==7){
  image(img[7],a1,b1,47,47);
    x1=162;
  } 
  else if(lixo==8){
  image(img[8],a1,b1,52,47);
    x1=162;
  }  
  else if(lixo==9){
    image(img[9],a1,b1,30,45);
    x1=288;
    }
  else if(lixo==10){
  image(img[10],a1,b1,30,45);
    x1=288;
  }
   else if(lixo==11){
  image(img[11],a1,b1,38,55);
    x1=288;
  } 
  else if(lixo==12){
  image(img[12],a1,b1,30,55);
    x1=288;
  }  
  else if(lixo==13){
  image(img[13],a1,b1,28,60);
    x1=410;
  }
  else if(lixo==14){
  image(img[14],a1,b1,30,45);
    x1=410;
  }
  else if(lixo==15){
  image(img[15],a1,b1,32,37);
    x1=410;
  }  
  else if(lixo==16){
  image(img[16],a1,b1,25,55);
    x1=410;
  }  
  else if(lixo==17){
  image(img[17],a1,b1,30,45);
    x1=529;
  }
  else if(lixo==18){
  image(img[18],a1,b1,30,45);
    x1=529;
  }
  else if(lixo==19){
  image(img[19],a1,b1,35,45);
    x1=529;
  } 
  else if(lixo==20){
  image(img[20],a1,b1,55,37);
    x1=529;
  }
      while(b1==306){
  if(dista<=43){
  p=p+1;
  }
    else{ 
      vida=vida-1;
    }
    b1++;
  }
  }
    else{
      if(star==1){
      image(img[24],a1,b1,55,50);
        x1=529;
      }
      else if(star==2){
        image(img[25],a1,b1,55,50);
        x1=288;
      }
      else if(star==3){
        image(img[26],a1,b1,55,50);
        x1=162;
      }
      else if(star==4){
        image(img[27],a1,b1,55,50);
        x1= 42
      }
      else if(star==5){
      image(img[28],a1,b1,55,50);
        x1=410;
      }
        while(b1==306){
  if(dista<=43){
  p=p+10;
  }
    else{ 
      vida=vida-1;
    }
    b1++;
    somat=somat+5
  }
      
    }
  
  //comandos do lixo
  if (keyIsDown(LEFT_ARROW))
    a1-=3+(n*2);

  if (keyIsDown(RIGHT_ARROW))
    a1+=3+(n*2);

  if (keyIsDown(DOWN_ARROW))
    b1+=2;
  
    if(b1==306&&keyIsDown(DOWN_ARROW))
      b1=b1+1;
      
  textSize(20)
     stroke(51);
  text("Pontos: "+p,7,18);
  text("Nivel: "+n,530,18);
 //text("distancia: "+dista,380,18);
  text("Vidas: ",162,18);
    
    //DESENHO DOS CORAÇÕES
    if(vida==3){
    image(img[23],222,2,65,18);
    }
    else if(vida==2){
    image(img[22],222,2,45,18);
    }
    else if(vida==1){
    image(img[21],222,0,25,25);
    }
    if(n>5){
    tela=5;
    }
  }
  
  //tela final
  if(tela==4){
    background(100,80,100);
 textSize(30)
    textFont('Modak');
    fill(1,112,1);
    text("PERDESTES",220,150);
    fill(124,252,0)
    rect(75, 260, 455, 50, 20);
    textSize(22)
    textFont('Modak');
    fill(1,139,34);
    text("Para continuar, aperte barra de espaço",104,290)
    if(keyIsDown(32)){
    tela=3;
    vida=3;
    p=0;
      n=1;
    }
  }
  
  if(tela==5){
  textSize(30)
    textFont('Modak');
     fill(255,255,0)
    rect(85, 120, 455, 50, 20);
    fill(21,65,0);
    text("CHEGASTES ATÉ O FINAL",150,152);
    text("PARABÉNS",240,100);
  }
  
  //os dados da tela do jogo acabam aqui
  
  dista= parseInt((dist(a1,b1,x1,303)));
  
  if(vida<=0){
  tela=4;
  }
}

/*
O QUE FALTA NO JOGO
-Melhorar o design da tela inicial
-Procurar imagens para fundo do tutorial e da tela de "game over"
-colocar o texto na tela de tutorial
-acrescentar as estrelas na imagem de tutorial
*/
